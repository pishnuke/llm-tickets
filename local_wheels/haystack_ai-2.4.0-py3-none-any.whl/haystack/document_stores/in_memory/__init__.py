# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

from haystack.document_stores.in_memory.document_store import InMemoryDocumentStore

__all__ = ["InMemoryDocumentStore"]
