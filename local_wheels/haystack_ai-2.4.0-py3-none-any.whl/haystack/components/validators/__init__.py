# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

from haystack.components.validators.json_schema import JsonSchemaValidator

__all__ = ["JsonSchemaValidator"]
