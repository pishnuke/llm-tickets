# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

from haystack.components.fetchers.link_content import LinkContentFetcher

__all__ = ["LinkContentFetcher"]
